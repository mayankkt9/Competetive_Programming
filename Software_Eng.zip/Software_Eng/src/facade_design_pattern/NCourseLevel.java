package facade_design_pattern;

public enum NCourseLevel {

	HIGH_LEVEL, LOW_LEVEL;
}
