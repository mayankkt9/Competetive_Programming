package facade_design_pattern;

public enum UserType {
	Student, Instructor;
}
