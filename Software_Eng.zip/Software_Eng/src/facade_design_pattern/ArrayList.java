package facade_design_pattern;

import java.util.List;

public abstract class ArrayList {
	
}
