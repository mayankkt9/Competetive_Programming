
/**
 * @author Parikshith Kedilaya Mallar
 *
 */
public enum ShapesEnum {
	TRIANGLE,
	SQUARE,
	CIRCLE
}
